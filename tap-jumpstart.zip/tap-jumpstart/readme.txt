If you want start tap-jumpstart on linux OS run ./start.sh from terminal.
If you want run the installer on windows OS run start.bat from cmd prompt (not powershell).

In terminal or cmd prompt you must navigate to (cd into) the unzipped directory and execute ./start.sh or start.bat. 
eg: cd ~/Downloads/tap-jumpstart/ && ./start.sh. (you must not do ~/Downloads/start.sh).