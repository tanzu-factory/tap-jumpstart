#!/bin/bash

function helpFunction()
{
    printf "\n"
    echo "Usage:"
    echo -e "\t-n | --name Optional. Pass this parameter along with a name that will act as suffix to the default name 'tap-jumpstart'. eg: tap-jumpstart-env1"
    echo -e "\t-b | --bind Optional. Pass value in the format such as <IP>:<PORT>. If not provided the default is 127.0.0.1:8020. eg: --bind 192.168.220.2:8080"
    echo -e "\t-h | --help"
    printf "\n"
}

function openBrowser() 
{
    local foundImage=''
    while [[ -z $foundImage ]]; do
        foundImage=$(docker ps --filter "ancestor=$1" --format '{{ .Image }}')
        if [[ -n $foundImage ]]; then
            open -n "http://$2:$3" > /dev/null 2>&1 || x-www-browser http://$2:$3 > /dev/null 2>&1 || printf "\nPlease open this url to access jumpstart: http://$2:$3\n"
        fi
        sleep 2
    done
}


initPort="8020"
bind="127.0.0.1:$initPort"
name='tap-jumpstart'
image='harbor.services.tanzu.rocks/tanzu-factory/tap-jumpstart'
tag=$(curl -sf https://raw.githubusercontent.com/tanzu-factory/tap-jumpstart/main/VERSION || cat VERSION)
ishelp=""

# read the options
TEMP=`getopt -o b:n:h --long bind:,name:,help -n $0 -- "$@"`
eval set -- "$TEMP"
while true ; do
    case "$1" in
        -b | --bind )
            case "$2" in
                "" ) bind=$bind; shift 2 ;;
                * ) bind=$2;  shift 2 ;;
            esac ;;
        -n | --name )
            case "$2" in
                "" ) name=$name; shift 2 ;;
                * ) name="$name-$2";  shift 2 ;;
            esac ;;
        -h | --help ) ishelp='y'; helpFunction; exit;; 
        -- ) shift; break;; 
        * ) break;;
    esac
done

printf "\n\nstarting $name...\n"
sleep 5


if [[ $ishelp != 'y' ]]
then
    isexistsdi=$(docker images | grep -w $name | awk '{print $2}' | grep -w saved)
    if [[ $isexistsdi == 'saved' ]]
    then
        printf "\nfound existing docker image with name=$name:saved.\nWould you like to use the saved instance?"
        confirmed=""
        while true; do
            read -p "please confirm [y/n]: " yn
            case $yn in
                [Yy]* ) printf "you confirmed yes\n"; confirmed='y'; break;;
                [Nn]* ) printf "You confirmed no.\n"; confirmed='n'; break;;
                * ) printf "${redcolor}Please answer y or n.${normalcolor}\n";;
            esac
        done
        if [[ $confirmed == "y" ]]
        then
            image=$name
            tag='saved'
        fi
    fi
    
    
    hostip=$(echo $bind | awk 'BEGIN { FS=":" } { print $1 }')
    port=$(echo $bind | awk 'BEGIN { FS=":" } { print $2 }')

    printf "\n"
    printf "\nDocker image name: $image:$tag"
    printf "\nContainer name: $name"
    printf "\nMount Dir: ${PWD}/binaries:/workspace/binaries"
    printf "\nbind: $hostip:$port"
    printf "\ncontainer terminal: docker exec -it $name /bin/bash"
    printf "\n"

    
    openBrowser "$image:$tag" $hostip $port &

    if [[ $tag == 'saved' ]]
    then
        docker run --privileged=true -p $hostip:$port:$port -p $hostip:$((port+1)):$((port+1)) --add-host host.docker.internal:host-gateway -e 'SAVED=YES' -e 'CLIENTHOST='$hostip -e 'PORT='$port -it --rm -v "${PWD}"/binaries:/workspace/binaries/ -v /var/run/docker.sock:/var/run/docker.sock --name $name $image:$tag
    else
        docker run --privileged=true -p $hostip:$port:$port -p $hostip:$((port+1)):$((port+1)) --add-host host.docker.internal:host-gateway -e 'CLIENTHOST='$hostip -e 'PORT='$port -it --rm -v "${PWD}"/binaries:/workspace/binaries/ -v /var/run/docker.sock:/var/run/docker.sock --name $name $image:$tag
    fi

    # Launch the browser automatically using this but trying to use index.js in node instead
    # open -n http://$hostip:$port
fi
unset ishelp
