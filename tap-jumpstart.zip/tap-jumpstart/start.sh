#!/bin/bash

function helpFunction()
{
    printf "\n"
    echo "Usage:"
    echo -e "\t-b | --bind Optional. Pass value in the format such as <IP>:<PORT>. If not provided the default is 127.0.0.1:8020. eg: --bind 192.168.220.2:8080"
    echo -e "\t-h | --help"
    printf "\n"
}

bind="127.0.0.1:8020"

printf "\n\nstarting tap-jumpstart...\n"
sleep 5

# read the options
TEMP=`getopt -o b:h --long bind:,help -n $0 -- "$@"`
eval set -- "$TEMP"
while true ; do
    case "$1" in
        -b | --bind )
            case "$2" in
                "" ) bind='127.0.0.1:8020'; shift 2 ;;
                * ) bind=$2;  shift 2 ;;
            esac ;;
        -h | --help ) ishelp='y'; helpFunction; break;; 
        -- ) shift; break;; 
        * ) break;;
    esac
done

if [[ $ishelp != 'y' ]]
then
    image='harbor.services.tanzu.rocks/tanzu-factory/tap-jumpstart'
    tag='latest'
    printf "\nchecking for existing docker image with name=tap-jumpstart:saved..."
    isexistsdi=$(docker images | grep -w tap-jumpstart | awk '{print $2}' | grep -w saved)
    if [[ $isexistsdi == 'saved' ]]
    then
        image='tap-jumpstart'
        tag='saved'
    else
        printf "not found.\n"
    fi
    name='tap-jumpstart'
    
    hostip=$(echo $bind | awk 'BEGIN { FS=":" } { print $1 }')
    port=$(echo $bind | awk 'BEGIN { FS=":" } { print $2 }')

    printf "\n"
    printf "\nDocker image name: $image:$tag"
    printf "\nContainer name: $image:$tag"
    printf "\nCurrent Dir: ${PWD}"
    printf "\nbind: $hostip:$port"
    printf "\n"

    if [[ $tag == 'saved' ]]
    then
        docker run --privileged=true -p $hostip:$port:$port -p $hostip:$((port+1)):$((port+1)) --add-host host.docker.internal:host-gateway -e 'SAVED=YES' -e 'CLIENTHOST='$hostip -e 'PORT='$port -it --rm -v ${PWD}/binaries:/workspace/binaries/ -v /var/run/docker.sock:/var/run/docker.sock --name $name $image:$tag
    else
        docker run --privileged=true -p $hostip:$port:$port -p $hostip:$((port+1)):$((port+1)) --add-host host.docker.internal:host-gateway -e 'CLIENTHOST='$hostip -e 'PORT='$port -it --rm -v ${PWD}/binaries:/workspace/binaries/ -v /var/run/docker.sock:/var/run/docker.sock --name $name $image:$tag
    fi
fi
unset ishelp
